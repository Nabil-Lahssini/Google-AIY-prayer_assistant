# __init__.py

# Version of the aiy_prayer package
__version__ = "1.0.1"